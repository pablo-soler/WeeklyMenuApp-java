package com.example.menusemanal;

import androidx.annotation.NonNull;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BDRecipes implements Serializable {
    //tendría variables que me digan cuantos recetas hay por dia y tipo
    //al tener int en el tipo y dia se puede usar como indice de este array

    private List<Recipe> recipes;
    private int cont[]; //ALMACENO LA CANTIDAD DE RECIPES POR ESPACIO
        //Constructor buit sempre que treballem amb estructures de dades

    public BDRecipes(){
        this.recipes = new ArrayList<Recipe>();
        this.cont = new int[7];
    }

    public List<Recipe> getRecipes() {
        return recipes;
    }

    public int getContDay(int day){
        return this.cont[day];
    }

    public int getCont(){
        int suma = 0;
        for(int i = 0; i<7; i++){
            suma = cont[i] + suma;
        }
        return suma;
    }

    public List<Recipe> getRecipesByDay(int day) {
        List<Recipe> recipesDay = new ArrayList<Recipe>();
        for (Recipe r : recipes) {
            if (r.getDay() == day) {
                recipesDay.add(r);
            }
        }
        return recipesDay;
    }


    public static  BDRecipes getFromFile(FileInputStream fis) { //necesitamos el File impotStrema porque es un fichero de entrada y queremos que se introduzca archivo cualqueira object
        //necesitamos un flujo de objetos
        try { //hay que hacer esta movida por si el archivo no esta
            ObjectInputStream ois = new ObjectInputStream(fis);
            //necesitamos leer un objeto del flujo este
            BDRecipes bd = (BDRecipes) ois.readObject(); //te da un objeto pero necesitamos una bdSong por lo que hay que hacer casitng
            return bd;
        }
        catch (Exception e){
            return new BDRecipes();
        }
    }


    public boolean writeToFile(FileOutputStream fos){
        try {
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(this);
            return true;
        } catch (Exception e){
            return false;
        }
    }


    public static BDRecipes getDummyRecipes(){
        BDRecipes bd = new BDRecipes();
        //LAS PRIMERAS RECETAS DE LA BASE DE DATOS LA USARE PARA LOS TÍTULOS
        bd.getRecipes().add(new Recipe("MONDAY", 0, 0, "", ""));
        bd.getRecipes().add(new Recipe("TUESDAY", 0, 0, "", ""));
        bd.getRecipes().add(new Recipe("WEDNESDAY", 0, 0, "", ""));
        bd.getRecipes().add(new Recipe("THURSDAY", 0, 0, "", ""));
        bd.getRecipes().add(new Recipe("FRIDAY", 0, 0, "", ""));
        bd.getRecipes().add(new Recipe("SATURDAY", 0, 0, "", ""));
        bd.getRecipes().add(new Recipe("SUNDAY", 0, 0, "", ""));
        for (int i=0;i<=6; i++){
            bd.cont[i] = 3;
            for (int j=0;j<=2; j++){
                bd.getRecipes().add(new Recipe("Title "+i, i, j, "ingrediente", "descripcion"));
            }
        }
        return bd;
    }


    public String toString() {

        String results = Integer.toString(cont[0]);
        results += "//";
        results += Integer.toString(cont[1]);
        results += "//";
        results +=Integer.toString(cont[2]);
        results += "//";
        results += Integer.toString(cont[3]);
        results += "//";
        results +=Integer.toString(cont[4]);
        results += "//";
        results += Integer.toString(cont[5]);
        results += "//";
        results +=Integer.toString(cont[6]);
        results += "//";

        for(Recipe d : recipes) {
            results += d.toString();
        }
        return results;

    }
}
