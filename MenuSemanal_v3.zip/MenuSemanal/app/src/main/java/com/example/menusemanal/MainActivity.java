package com.example.menusemanal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;

import android.widget.ListView;


import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    private BDRecipes bd;
    private ListView all;
    private ListView mon;
    private ListView tue;
    private ListView wed;
    private ListView thu;
    private ListView fri;
    private ListView sat;
    private ListView sun;
    private ArrayAdapter<Recipe> adapter;
    private RecipeAdapter adapterS;
    private FloatingActionButton fabAdd;
    private int editingRecipe = -1;
    private static int REQUEST_CODE_NEW_RECIPE= 0; //son los codigos para saber que hacer en la actividad de EDITRECIPE
    private static int REQUEST_CODE_EDIT_RECIPE= 1;
    private static String FILE_NAME = "bdrecipes.obj"; //el nombre que tiene el objeto java que queremos guardar, nosp Podemos inventar la extension

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //--------INICIALIZO LA BBDD
        //bd= BDRecipes.getDummyRecipes();
        //saveToFile();

        //view -------toolWindow ---------Device file explorere
        //ahi estan los ficheros del dispositivo
        //carpeta data ----- app ------ y aqui esta la nuestra
        try{ //se puede producir un error porque hay fallos de lectura o porque no hay fichero
            bd = BDRecipes.getFromFile(this.openFileInput(FILE_NAME)); //tiene que ser un fichero, MainActivity tiene acceso a metodos de Activity que tiene metodos para get ficheros
        }catch (Exception e){
            bd = new BDRecipes();
        }
        //System.out.println( bd.toString());

    //EN CADA UNA DE LAS LIST(DIA) METEMOS SUS RECETAS
        adapterS = new RecipeAdapter(this, R.layout.recipe_item_layout,R.id.textViewTitle,bd.getRecipes(),R.id.textViewType);
        all =  findViewById(R.id.all);
        for (int j=0; j<7; j++){
            adapterS.addSectionHeaderItem(bd.getRecipes().get(j));
            for (int i = 7; i < (bd.getContDay(j)+7); i++) {
                adapterS.addItem(bd.getRecipes().get(i));
            }
        }

        all.setAdapter(adapterS);

        /*
        mon =  findViewById(R.id.mon);
        adapter = new RecipeAdapter(this, R.layout.recipe_item_layout,R.id.textViewTitle,bd.getRecipesByDay(Recipe.MONDAY),R.id.textViewType);
        mon.setAdapter(adapter);

        tue = findViewById(R.id.tue);
        adapter = new RecipeAdapter(this, R.layout.recipe_item_layout,R.id.textViewTitle,bd.getRecipesByDay(Recipe.TUESDAY),R.id.textViewType);
        tue.setAdapter(adapter);

        wed = findViewById(R.id.wed);
        adapter = new RecipeAdapter(this, R.layout.recipe_item_layout,R.id.textViewTitle,bd.getRecipesByDay(Recipe.WEDNESDAY),R.id.textViewType);
        wed.setAdapter(adapter);

        thu = findViewById(R.id.thu);
        adapter = new RecipeAdapter(this, R.layout.recipe_item_layout,R.id.textViewTitle,bd.getRecipesByDay(Recipe.THURSDAY),R.id.textViewType);
        thu.setAdapter(adapter);

        fri = findViewById(R.id.fri);
        adapter = new RecipeAdapter(this, R.layout.recipe_item_layout,R.id.textViewTitle,bd.getRecipesByDay(Recipe.FRIDAY),R.id.textViewType);
        fri.setAdapter(adapter);

        sat = findViewById(R.id.sat);
        adapter = new RecipeAdapter(this, R.layout.recipe_item_layout,R.id.textViewTitle,bd.getRecipesByDay(Recipe.SATURDAY),R.id.textViewType);
        sat.setAdapter(adapter);

        sun = findViewById(R.id.sun);
        adapter = new RecipeAdapter(this, R.layout.recipe_item_layout,R.id.textViewTitle,bd.getRecipesByDay(Recipe.SUNDAY),R.id.textViewType);
        sun.setAdapter(adapter);
*/


        //Un listener es una classe que quan es podueix aquell event ejecuta un metode.
        //El que hem de fer es asociar un listener al list view mitjançant un set (set+nom del event+listener)

        //Per no crear la classe del listener creem una classe anonima (creo un nou objecte de una classe que no te nom i implementa una interficie)
/*
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Només ens fa falta la posicio, ja que coincideix amb la posició del arraylist
                editRecipe(position);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                //deleteSong(position);
                //abans del delete hem de cridar a un mètode per demanar la confirmació, desde aquest metode esborrarem.
                deleteConfirmedSong(position);
                return true;
            }
        });

        fabAdd = findViewById(R.id.floatingActionButton);
        //hem de passarli un objecte de una clase que implementi un listener (clase anonima)
        fabAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addRecipe();
            }
        });

*/

    }

/*
    private void addRecipe() {
        Log.d("addRecipe","add recipe");

        Intent intent = new Intent(this, EditRecipeActivity.class);

        //tenemos que pasarle el this y la clase correspondiente a la actividad que queremos que se abra

        startActivityForResult(intent, REQUEST_CODE_NEW_RECIPE);
        // comenzamos la actividad per ESPERAMOS UN RESULTADO

    }


    private void deleteConfirmedSong(final int position) {
        //Farem servir una classe pròpia de Android AlertDialogue.
        //en comptes de crear un objecte de la classe, (dins te una altre classe que te un builder de dialegs per defecte amb un title, confirmar cancelar...)
        //Context: dins de quin context es mopstrara el alert
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.titleAlertDialogDeleteRecipe);
        builder.setMessage(R.string.messageAlertDialogueDeleteRecipe);
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //per poder utilitzar position, aquesta variable té que ser final
                deleteSong(position);
            }
        });
        builder.setNegativeButton(android.R.string.cancel, null);
        //una vegada esta configurat creem el dialeg
        builder.create().show();
    }


    private void deleteSong(int position) {
        Log.d("deleteSong",bd.getRecipes().get(position).toString());
        bd.getRecipes().remove(position);
        //Despres de esborrar hem de actualitzar la vista
        //hem de notificar al adapter
        adapter.notifyDataSetChanged();
        saveToFile();
    }


    private void editRecipe(int position) {
        Log.d("editSong",bd.getRecipes().get(position).toString());
        editingRecipe = position;
        Intent intent = new Intent(this, EditRecipeActivity.class);

        //tenemos que pasarle el this y la clase correspondiente a la actividad que queremos que se abra

        intent.putExtra(EditRecipeActivity.SONG_PARAMETER, bd.getRecipes().get(position));
        //tiene que ser un put extra para llevar a la actividad que queremos abrir la cancion, y tienee que ser PutEXTRA (serializable )
        //para que Song sea serializable tiene que implementar una interficie que sea Seralizable

        startActivityForResult(intent, REQUEST_CODE_EDIT_RECIPE);

        // comenzamos la actividad per ESPERAMOS UN RESULTADO
    }

    //cuando acabauna actividad y vuelve a esta hay un metodo que se ejecuta en el que podemos mostrar el resultado dependeiendo de lo que hemos pedido en el strartActivityForResult



     @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        //miramos primero el resultcode para saber si ha ido como esperado la actividad y de esa forma tenemos data
       if(resultCode == RESULT_OK) {
            Recipe recipe = (Recipe) data.getSerializableExtra(EditRecipeActivity.SONG_PARAMETER_OUT);
            //el getExtra no permite sobreescritura por lo que hay un metodo especializado para cada objeto
            //coge el serializable con el nombre
            if(recipe!=null) {
                if(requestCode==REQUEST_CODE_NEW_RECIPE){
                    addSong(recipe); //es el metodo de abajo,
                }
                else if(requestCode==REQUEST_CODE_EDIT_RECIPE){
                    modifySong(recipe);
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data);

    }


    private void addSong(Recipe recipe) {
        bd.getRecipes().add(recipe); //insertamos en base de datos
        adapter.notifyDataSetChanged(); //actualizamos la vista
        listView.smoothScrollToPosition(bd.getRecipes().size()-1);
        saveToFile();

    }


    private void modifySong(Recipe recipe){
        if(editingRecipe!=-1){
            bd.getRecipes().set(editingRecipe, recipe);
            editingRecipe = -1;
            adapter.notifyDataSetChanged();
        }
    }
*/
    private void saveToFile(){
        try{
            bd.writeToFile(this.openFileOutput(FILE_NAME, MODE_PRIVATE));
        } catch (Exception e){}
        //el mdeçode private sobreescribe en los datos
    }


}
