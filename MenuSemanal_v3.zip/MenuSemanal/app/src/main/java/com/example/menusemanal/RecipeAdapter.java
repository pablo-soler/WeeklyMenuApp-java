package com.example.menusemanal;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public class RecipeAdapter extends ArrayAdapter<Recipe> {

    private static final int TYPE_ITEM = 0;
    private static final int TYPE_SEPARATOR = 1;

    private ArrayList<Recipe> mData = new ArrayList<Recipe>();
    private TreeSet<Integer> sectionHeader = new TreeSet<Integer>();

    private LayoutInflater mInflater;

    private int idResourceTitle;
    private int idResourceType;


    public RecipeAdapter(Context context, int resource, int idResourceTitle,
                         List<Recipe> objects, int idResourceType) {
        super(context, resource, idResourceTitle, objects);
        this.idResourceTitle = idResourceTitle;
        this.idResourceType = idResourceType;
        mInflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }



    public void addItem(final Recipe item) {
        mData.add(item);
        notifyDataSetChanged();
    }

    public void addSectionHeaderItem(final Recipe item) {
        mData.add(item);
        sectionHeader.add(mData.size() - 1);
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return sectionHeader.contains(position) ? TYPE_SEPARATOR : TYPE_ITEM;
    }

    @Override
    public int getViewTypeCount() {
        return 2;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Recipe getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }





    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
       
        Recipe recipe = this.getItem(position);

        int rowType = getItemViewType(position);
            switch (rowType) {
                case TYPE_ITEM:
                    View view1 = super.getView(position, convertView, parent);
                    TextView textViewTitle = view1.findViewById(idResourceTitle);
                    TextView textViewType = view1.findViewById(idResourceType);
                    textViewTitle.setText(recipe.getTitle());
                    textViewType.setText(Integer.toString(recipe.getType()));
                    return view1;

                case TYPE_SEPARATOR:
                    View view2 = mInflater.inflate(R.layout.snippet_item2, null);
                    TextView textSeparator = view2.findViewById(R.id.textSeparator);
                    textSeparator.setText(recipe.getTitle());
                    return view2;


            }




        return view;

        //position corresponent a la vista que estem creant per a cada canço


        //Assignar contingut a cadascun dels elements de la vista:



        //return view;
    }



    //El constructor ha de tenir el context










}
