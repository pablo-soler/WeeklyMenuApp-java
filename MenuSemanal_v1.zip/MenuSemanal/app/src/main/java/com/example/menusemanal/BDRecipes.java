package com.example.menusemanal;

import androidx.annotation.NonNull;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BDRecipes implements Serializable {
    //tendría variables que me digan cuantos recetas hay por dia y tipo
    //al tener int en el tipo y dia se puede usar como indice de este array

    private List<Recipe> recipes;
    private int cont[]; //ALMACENO LA CANTIDAD DE RECIPES POR ESPACIO
        //Constructor buit sempre que treballem amb estructures de dades

    public BDRecipes(){
        this.recipes = new ArrayList<Recipe>();
        this.cont = new int[21];
    }

    public List<Recipe> getRecipes() {
        return recipes;
    }


    public static  BDRecipes getFromFile(FileInputStream fis) { //necesitamos el File impotStrema porque es un fichero de entrada y queremos que se introduzca archivo cualqueira object
        //necesitamos un flujo de objetos
        try { //hay que hacer esta movida por si el archivo no esta
            ObjectInputStream ois = new ObjectInputStream(fis);
            //necesitamos leer un objeto del flujo este
            BDRecipes bd = (BDRecipes) ois.readObject(); //te da un objeto pero necesitamos una bdSong por lo que hay que hacer casitng
            return bd;
        }
        catch (Exception e){
            return new BDRecipes();
        }
    }


        public boolean writeToFile(FileOutputStream fos){
            try {
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                oos.writeObject(this);
                return true;
            } catch (Exception e){
                return false;
            }
        }


        public static BDRecipes getDummyRecipes(){
            BDRecipes bd = new BDRecipes();
            for (int i=0;i<=6; i++){
                for (int j=0;j<=2; j++){
                    bd.getRecipes().add(new Recipe("Title "+i, i, j, "ingrediente", "descripcion"));
                }
            }
            return bd;
        }


        public String toString() {
            String results = "+";
            for(Recipe d : recipes) {
                results += d.toString();
            }
            return results;

        }
}
