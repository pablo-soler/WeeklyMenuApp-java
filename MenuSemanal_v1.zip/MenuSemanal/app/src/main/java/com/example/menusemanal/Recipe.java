package com.example.menusemanal;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class Recipe implements Serializable {

    private String title;
    private int day;
        public static int MONDAY = 0;
        public static int TUESDAY = 1;
        public static int WEDNESDAY = 2;
        public static int THURSDAY = 3;
        public static int FRIDAY = 4;
        public static int SATURDAY = 5;
        public static int SUNDAY = 6;
    private int type;
        public static int BREAKFAST = 0;
        public static int LUNCH = 1;
        public static int DINNER = 2;
    private String ingredients;
    private String description;


    public Recipe(String title, int day, int type, String ingredients, String description) {
        this.title = title;
        this.day = day;
        this.type = type;
        this.ingredients = ingredients;
        this.description = description;
    }



    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getIngredients() {
        return ingredients;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public String toString() {
        return "RECETA: " + title + " /" + type + " /" + day + " /" + ingredients + " /" + description + " / \n";
    }
}
