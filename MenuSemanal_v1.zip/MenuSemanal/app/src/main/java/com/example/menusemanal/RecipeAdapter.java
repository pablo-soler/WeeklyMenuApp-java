package com.example.menusemanal;


import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class RecipeAdapter extends ArrayAdapter<Recipe> {


    private int idResourceTitle;
    private int idResourceType;

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = super.getView(position, convertView, parent);
        TextView textViewTitle = view.findViewById(idResourceTitle);
        TextView textViewType = view.findViewById(idResourceType);


        //position corresponent a la vista que estem creant per a cada canço

        Recipe recipe = this.getItem(position);

        //Assignar contingut a cadascun dels elements de la vista:

        textViewTitle.setText(recipe.getTitle());
        textViewType.setText(Integer.toString(recipe.getType()));


        return view;
    }

    //El constructor ha de tenir el context


    public RecipeAdapter(Context context, int resource, int idResourceTitle,
                       List<Recipe> objects, int idResourceType) {
        super(context, resource, idResourceTitle, objects);
        this.idResourceTitle = idResourceTitle;
        this.idResourceType = idResourceType;
    }
}
