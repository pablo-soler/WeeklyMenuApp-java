package com.example.menusemanal;

public class Test {

    public static void main(String[] args) {
        BDRecipes bd = new BDRecipes();
        System.out.println( bd.getDummyRecipes().getRecipesByDay(Recipe.MONDAY));
        System.out.println( bd.getDummyRecipes().getRecipes());

    }
}
