package com.example.menusemanal;


import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.TreeSet;

public class RecipeAdapter extends BaseAdapter {

    private static final int TYPE_ITEM = 0;
    private static final int TYPE_SEPARATOR = 1;
    private static final int TYPE_MAX_COUNT = TYPE_SEPARATOR + 1;

    private ArrayList<Recipe> mData = new ArrayList<Recipe>();
    private LayoutInflater mInflater;

    private TreeSet<Integer> sectionHeader = new TreeSet<Integer>();





    public RecipeAdapter(Context context) {
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }



    public void addItem(final Recipe item) {
        mData.add(item);
        notifyDataSetChanged();
    }

    public void addSectionHeaderItem(final Recipe item) {
        mData.add(item);
        sectionHeader.add(mData.size()-1);
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return sectionHeader.contains(position) ? TYPE_SEPARATOR : TYPE_ITEM;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_MAX_COUNT;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Recipe getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void updateReceiptsList(ArrayList<Recipe> newlist) {
        mData.clear();
        mData.addAll(newlist);
        this.notifyDataSetChanged();
        //actualiza pero no muestra la actualizacion en pantalla
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        int rowType = getItemViewType(position);

        if (convertView == null) {
            holder = new ViewHolder();
            switch (rowType) {
                case TYPE_ITEM:
                    convertView = mInflater.inflate(R.layout.recipe_item_layout, null);
                    holder.textViewTitle = convertView.findViewById(R.id.textViewTitle);
                    holder.textViewType = convertView.findViewById(R.id.textViewType);
                    holder.textViewTitle.setText(mData.get(position).getTitle());
                    holder.textViewType.setText(Integer.toString(mData.get(position).getType()));
                    convertView.setTag(holder);
                    break;

                case TYPE_SEPARATOR:
                    convertView = mInflater.inflate(R.layout.snippet_item2, null);
                    TextView textSeparator = convertView.findViewById(R.id.textSeparator);
                    textSeparator.setText(mData.get(position).getTitle());
                    convertView.setTag(holder);
                    break;
            }


        }else {
            holder = (ViewHolder)convertView.getTag();
        }

        return convertView;

    }



    public static class ViewHolder {
        public TextView textViewTitle;
        public TextView textViewType;
    }

    //El constructor ha de tenir el context
    public boolean onTouch(View v, MotionEvent event) {
// TODO Auto-generated method stub
        return false;
    }









}
