package com.example.menusemanal;

import androidx.annotation.NonNull;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.RecursiveAction;

public class BDRecipes implements Serializable {
    public static String[] days = {"MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"};

    private List<List<Recipe>> recipes;

    public BDRecipes(){
        this.recipes = new ArrayList<List<Recipe>>();
    }

    public List<List<Recipe>> getRecipes() {
        return recipes;
    }

  /*  public int getContDay(int day){
        return this.cont[day];
    }

    public void updateCont(){

        for(int j = 0; j<7; j++){
           cont[j] = 0 ;
        }

        int i = 0;
        for ( Recipe r : this.recipes) {
            if(i>6){
                cont[r.getDay()]++;
            }
            i++;
        }
    }

    public int getCont(){
        int suma = 0;
        for(int i = 0; i<7; i++){
            suma = cont[i] + suma;
        }
        return suma;
    }

    public List<Recipe> getRecipesByDay(int day) {
        List<Recipe> recipesDay = new ArrayList<Recipe>();
        for (Recipe r : recipes) {
            if (r.getDay() == day) {
                recipesDay.add(r);
            }
        }
        return recipesDay;
    }*/

  public List<Recipe> getRecipesByDay(int day) {
      return recipes.get(day);
  }


    public static  BDRecipes getFromFile(FileInputStream fis) { //necesitamos el File impotStrema porque es un fichero de entrada y queremos que se introduzca archivo cualqueira object
        //necesitamos un flujo de objetos
        try { //hay que hacer esta movida por si el archivo no esta
            ObjectInputStream ois = new ObjectInputStream(fis);
            //necesitamos leer un objeto del flujo este
            BDRecipes bd = (BDRecipes) ois.readObject(); //te da un objeto pero necesitamos una bdSong por lo que hay que hacer casitng
            return bd;
        }
        catch (Exception e){
            return new BDRecipes();
        }
    }


    public boolean writeToFile(FileOutputStream fos){
        try {
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(this);
            return true;
        } catch (Exception e){
            return false;
        }
    }


    public static BDRecipes getDummyRecipes(){
        BDRecipes bd = new BDRecipes();
        //LAS PRIMERAS RECETAS DE LA BASE DE DATOS LA USARE PARA LOS TÍTULOS
        for (int i=0;i<=6; i++){
            bd.getRecipes().add(new ArrayList<Recipe>());
            bd.getRecipes().get(i).add(new Recipe(days[i], i, -1, "", ""));
            for (int j=0;j<=2; j++){
                bd.getRecipes().get(i).add(new Recipe("Title "+i, i, j, "ingrediente", "descripcion"));
            }
        }
        return bd;
    }


    public String toString() {

        String results = "List Recipes: \n";
        for (int i=0;i<=6; i++){
            for(Recipe d : recipes.get(i)) {
                results += d.toString();
            }
        }
        return results;
    }
}
