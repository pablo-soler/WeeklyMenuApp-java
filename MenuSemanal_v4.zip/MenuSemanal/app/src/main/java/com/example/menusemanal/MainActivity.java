package com.example.menusemanal;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;


import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private BDRecipes bd;
    private ListView listView;
    private RecipeAdapter adapterS;
    private RecipeAdapter adapter;
    private FloatingActionButton fabAdd;
    private Recipe seeRecipe;
    private static int REQUEST_CODE_NEW_RECIPE= 0;
    private static int REQUEST_CODE_SEE_RECIPE= 1;
    public static int REQUEST_CODE_DELETE_RECIPE= 2;
    public static int REQUEST_CODE_EDIT_RECIPE= 3;
    private static String FILE_NAME = "bdrecipes.obj";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //--------INICIALIZO LA BBDD
        //bd= BDRecipes.getDummyRecipes();
        //saveToFile();

        //view -------toolWindow ---------Device file explorere
        //ahi estan los ficheros del dispositivo
        //carpeta data ----- app ------ y aqui esta la nuestra
        try{
            bd = BDRecipes.getFromFile(this.openFileInput(FILE_NAME));
        }catch (Exception e){
            bd = new BDRecipes();
        }


        adapter = new RecipeAdapter(this);
        listView.setAdapter(adapter);

/*
    //EN CADA UNA DE LAS LIST(DIA) METEMOS SUS RECETAS
        adapterS = new RecipeAdapter(this);
        listView =  findViewById(R.id.all);
        int cont = 6;
        for (int j=0; j<7; j++){
            adapterS.addSectionHeaderItem(bd.getRecipes().get(j));
            for (int i = 0; i < bd.getContDay(j); i++) {
                cont++;
                adapterS.addItem(bd.getRecipes().get(cont));
                //CUANDO REALIZO SCROLL SE DESORDENA TODOS
            }
        }
        listView.setAdapter(adapterS);
*/


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Recipe item = (Recipe) parent.getItemAtPosition(position);
                if(bd.getRecipes().indexOf(item)<7){
                    System.out.println(item.getTitle());
                }else{
                System.out.println(position);
                seeRecipe(item);
                }

            }
        });

        /*

        fabAdd = findViewById(R.id.floatingActionButton);
        //hem de passarli un objecte de una clase que implementi un listener (clase anonima)
        fabAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addRecipe();
            }
        });

*/

    }

/*
    private void addRecipe() {
        Log.d("addRecipe","add recipe");

        Intent intent = new Intent(this, EditRecipeActivity.class);

        //tenemos que pasarle el this y la clase correspondiente a la actividad que queremos que se abra

        startActivityForResult(intent, REQUEST_CODE_NEW_RECIPE);
        // comenzamos la actividad per ESPERAMOS UN RESULTADO

    }



*/



    private void seeRecipe(Recipe r) {
        seeRecipe = r;
        Log.d("seeRecipe",r.toString());
        Intent intent = new Intent(this, DetailRecipeActivity.class);
        intent.putExtra(DetailRecipeActivity.RECIPE_PARAMETER, r);
        startActivityForResult(intent, REQUEST_CODE_SEE_RECIPE);
        //startActivity(intent);
    }



/*
     @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        //miramos primero el resultcode para saber si ha ido como esperado la actividad y de esa forma tenemos data
       if(resultCode == REQUEST_CODE_DELETE_RECIPE) {
           Log.d("deleteSong",seeRecipe.toString());
           bd.getRecipes().remove(seeRecipe);
           bd.updateCont();
           adapterS.updateReceiptsList((ArrayList<Recipe>) bd.getRecipes());
           saveToFile();
        } else if (resultCode == REQUEST_CODE_EDIT_RECIPE) {
           Recipe recipe = (Recipe) data.getSerializableExtra(DetailRecipeActivity.RECIPE_PARAMETER_OUT);
                int indexSeeRecipe =  bd.getRecipes().indexOf(seeRecipe);
               bd.getRecipes().set(indexSeeRecipe, recipe);
               bd.updateCont();
               adapterS.updateReceiptsList((ArrayList<Recipe>) bd.getRecipes());
               saveToFile();
           Log.d("EDITED", bd.getRecipes().get(indexSeeRecipe).toString());
         }

        super.onActivityResult(requestCode, resultCode, data);
    }
*/


    private void saveToFile(){
        try{
            bd.writeToFile(this.openFileOutput(FILE_NAME, MODE_PRIVATE));
        } catch (Exception e){}

    }





}
